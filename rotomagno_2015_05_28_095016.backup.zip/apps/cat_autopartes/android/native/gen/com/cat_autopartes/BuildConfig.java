/** Automatically generated file. DO NOT MODIFY */
package com.cat_autopartes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}